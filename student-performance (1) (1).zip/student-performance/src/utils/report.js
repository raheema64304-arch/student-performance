export function downloadTextFile(filename, content) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

export function buildModelReport({ summary, trainingResult }) {
  const { metrics, trainingSamples, testingSamples, epochs } = trainingResult
  const now = new Date().toLocaleString()

  return `STUDENT PERFORMANCE ANALYTICS — MODEL REPORT
Generated: ${now}

DATASET SUMMARY
Total Students:        ${summary.totalStudents}
Average Score:         ${summary.averageScore.toFixed(2)}
Average Attendance:    ${summary.averageAttendance.toFixed(2)}%
Average Study Hours:   ${summary.averageStudyHours.toFixed(2)} hrs
Highest Score:         ${summary.highestScore.toFixed(2)}
Lowest Score:          ${summary.lowestScore.toFixed(2)}
Avg Previous Marks:    ${summary.averagePreviousMarks.toFixed(2)}
Avg Assignment Score:  ${summary.averageAssignmentScore.toFixed(2)}
Avg Midterm Score:     ${summary.averageMidtermScore.toFixed(2)}

MODEL
Status:            Ready
Training Samples:  ${trainingSamples}
Testing Samples:   ${testingSamples}
Training Epochs:   ${epochs}

EVALUATION METRICS (on held-out test set)
MAE:   ${metrics.mae.toFixed(3)}
MSE:   ${metrics.mse.toFixed(3)}
RMSE:  ${metrics.rmse.toFixed(3)}
R2:    ${metrics.r2.toFixed(3)}
`
}

export function buildPredictionReport({ score, category, input }) {
  const now = new Date().toLocaleString()
  return `STUDENT PERFORMANCE ANALYTICS — PREDICTION REPORT
Generated: ${now}

INPUT
Study Hours:          ${input.study_hours}
Attendance:            ${input.attendance}%
Previous Marks:        ${input.previous_marks}
Assignment Score:      ${input.assignment_score}
Midterm Score:         ${input.midterm_score}
Participation:         ${input.participation}
Sleep Hours:           ${input.sleep_hours}
Internet Access:       ${input.internet_access}
Extracurricular:       ${input.extracurricular}

RESULT
Predicted Score:  ${score.toFixed(1)} / 100
Category:         ${category.label}
`
}
