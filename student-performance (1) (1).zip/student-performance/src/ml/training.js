import * as tf from '@tensorflow/tfjs'
import { buildModel, INPUT_SIZE } from './model'
import {
  FEATURE_COLUMNS,
  computeStats,
  encodeYesNo,
  normalizeValue,
  denormalizeValue,
  trainTestSplit,
} from './preprocessing'

/** Turns a dataset row into the full normalized input vector the model expects. */
function encodeRow(row, stats) {
  const numeric = FEATURE_COLUMNS.map((col) =>
    normalizeValue(row[col], stats[col].min, stats[col].max),
  )
  return [...numeric, encodeYesNo(row.internet_access), encodeYesNo(row.extracurricular)]
}

/**
 * Trains the regression model on the given dataset rows.
 * onEpoch(epoch, totalEpochs) is called after every epoch so the UI can
 * show live training progress.
 */
export async function trainModel(rows, { epochs = 50, onEpoch } = {}) {
  const { trainRows, testRows } = trainTestSplit(rows, 0.2)
  const stats = computeStats(trainRows)

  const trainX = trainRows.map((r) => encodeRow(r, stats))
  const trainY = trainRows.map((r) => [normalizeValue(r.final_score, stats.final_score.min, stats.final_score.max)])

  const testX = testRows.map((r) => encodeRow(r, stats))
  const testYRaw = testRows.map((r) => r.final_score)

  const xs = tf.tensor2d(trainX)
  const ys = tf.tensor2d(trainY)

  const model = buildModel(INPUT_SIZE)

  await model.fit(xs, ys, {
    epochs,
    batchSize: 16,
    shuffle: true,
    verbose: 0,
    callbacks: {
      onEpochEnd: async (epoch) => {
        if (onEpoch) onEpoch(epoch + 1, epochs)
        await tf.nextFrame()
      },
    },
  })

  const testXs = tf.tensor2d(testX)
  const predsNormalized = model.predict(testXs)
  const predsArray = await predsNormalized.array()
  const predsRaw = predsArray.map(([v]) =>
    clampScore(denormalizeValue(v, stats.final_score.min, stats.final_score.max)),
  )

  const metrics = evaluate(testYRaw, predsRaw)

  xs.dispose()
  ys.dispose()
  testXs.dispose()
  predsNormalized.dispose()

  return {
    model,
    stats,
    metrics,
    trainingSamples: trainRows.length,
    testingSamples: testRows.length,
    epochs,
    actualVsPredicted: testYRaw.map((actual, i) => ({ actual, predicted: predsRaw[i] })),
  }
}

function clampScore(value) {
  return Math.max(0, Math.min(100, value))
}

function evaluate(actual, predicted) {
  const n = actual.length
  const errors = actual.map((a, i) => a - predicted[i])
  const absErrors = errors.map(Math.abs)
  const squaredErrors = errors.map((e) => e * e)

  const mae = absErrors.reduce((a, b) => a + b, 0) / n
  const mse = squaredErrors.reduce((a, b) => a + b, 0) / n
  const rmse = Math.sqrt(mse)

  const meanActual = actual.reduce((a, b) => a + b, 0) / n
  const ssTot = actual.reduce((a, v) => a + (v - meanActual) ** 2, 0)
  const ssRes = squaredErrors.reduce((a, b) => a + b, 0)
  const r2 = ssTot === 0 ? 0 : 1 - ssRes / ssTot

  return { mae, mse, rmse, r2 }
}

/** Runs a single prediction for a form-submitted student profile. */
export function predictScore(model, stats, input) {
  const vector = encodeRow(input, stats)
  const inputTensor = tf.tensor2d([vector])
  const outputTensor = model.predict(inputTensor)
  const [[normalizedValue]] = outputTensor.arraySync()
  inputTensor.dispose()
  outputTensor.dispose()
  const raw = denormalizeValue(normalizedValue, stats.final_score.min, stats.final_score.max)
  return clampScore(raw)
}

export function categorize(score) {
  if (score >= 80) return { label: 'Excellent', color: '#3F6659' }
  if (score >= 70) return { label: 'Good', color: '#5C8A6F' }
  if (score >= 60) return { label: 'Average', color: '#C99A3A' }
  if (score >= 50) return { label: 'Below Average', color: '#C17A3B' }
  return { label: 'Poor', color: '#B3462F' }
}
