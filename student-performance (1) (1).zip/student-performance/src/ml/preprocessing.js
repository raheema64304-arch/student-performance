// Feature columns used as model inputs, in a fixed order.
export const FEATURE_COLUMNS = [
  'study_hours',
  'attendance',
  'previous_marks',
  'assignment_score',
  'midterm_score',
  'participation',
  'sleep_hours',
]

export const VALID_RANGES = {
  study_hours: [0, 24],
  attendance: [0, 100],
  previous_marks: [0, 100],
  assignment_score: [0, 100],
  midterm_score: [0, 100],
  participation: [0, 100],
  sleep_hours: [0, 24],
}

export function encodeYesNo(value) {
  return value === 'Yes' ? 1 : 0
}

/** Builds a raw [study_hours, attendance, ...] feature vector from a dataset row. */
export function rowToFeatureVector(row) {
  return FEATURE_COLUMNS.map((col) => row[col])
}

/** Computes per-feature min/max (and for the target) from training rows only. */
export function computeStats(rows) {
  const stats = {}
  FEATURE_COLUMNS.forEach((col) => {
    const values = rows.map((r) => r[col])
    stats[col] = { min: Math.min(...values), max: Math.max(...values) }
  })
  const targets = rows.map((r) => r.final_score)
  stats.final_score = { min: Math.min(...targets), max: Math.max(...targets) }
  return stats
}

export function normalizeValue(value, min, max) {
  if (max === min) return 0
  return (value - min) / (max - min)
}

export function denormalizeValue(value, min, max) {
  return value * (max - min) + min
}

/** Normalizes a raw feature vector using stats computed on the training split. */
export function normalizeFeatureVector(vector, stats) {
  return vector.map((v, i) => normalizeValue(v, stats[FEATURE_COLUMNS[i]].min, stats[FEATURE_COLUMNS[i]].max))
}

/** Shuffles and splits rows into 80% train / 20% test. */
export function trainTestSplit(rows, testRatio = 0.2, seed = 42) {
  const shuffled = seededShuffle(rows, seed)
  const testSize = Math.max(1, Math.round(shuffled.length * testRatio))
  const testRows = shuffled.slice(0, testSize)
  const trainRows = shuffled.slice(testSize)
  return { trainRows, testRows }
}

// Deterministic shuffle so results are reproducible across runs.
function seededShuffle(array, seed) {
  const result = [...array]
  let s = seed
  const random = () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1))
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}

export function validateInput(field, value) {
  const [min, max] = VALID_RANGES[field] || [0, 100]
  if (value === '' || value === null || value === undefined || Number.isNaN(Number(value))) {
    return 'Enter a number.'
  }
  const num = Number(value)
  if (num < min || num > max) {
    return `Must be between ${min} and ${max}.`
  }
  return null
}
