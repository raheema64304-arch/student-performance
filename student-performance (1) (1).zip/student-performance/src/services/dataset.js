import Papa from 'papaparse'

const NUMERIC_FIELDS = [
  'study_hours',
  'attendance',
  'previous_marks',
  'assignment_score',
  'midterm_score',
  'participation',
  'sleep_hours',
  'final_score',
]

/**
 * Loads and parses the student dataset shipped with the app.
 * Throws a descriptive error the UI can surface if loading fails.
 */
export async function loadDataset() {
  let response
  try {
    response = await fetch('/data/students.csv')
  } catch (err) {
    throw new Error('Could not reach the dataset file. Check your connection and reload.')
  }

  if (!response.ok) {
    throw new Error(`Dataset file not found (status ${response.status}). Expected public/data/students.csv.`)
  }

  const csvText = await response.text()

  const parsed = Papa.parse(csvText, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
  })

  if (parsed.errors && parsed.errors.length > 0) {
    throw new Error('The dataset CSV is malformed and could not be parsed.')
  }

  const rows = parsed.data.filter((row) => {
    // Drop rows with missing/invalid numeric values.
    return NUMERIC_FIELDS.every((field) => typeof row[field] === 'number' && !Number.isNaN(row[field]))
      && (row.internet_access === 'Yes' || row.internet_access === 'No')
      && (row.extracurricular === 'Yes' || row.extracurricular === 'No')
  })

  if (rows.length < 20) {
    throw new Error('Dataset has too few valid rows to train a reliable model.')
  }

  return rows
}

export function computeSummary(rows) {
  const scores = rows.map((r) => r.final_score)
  const attendance = rows.map((r) => r.attendance)
  const studyHours = rows.map((r) => r.study_hours)

  const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

  return {
    totalStudents: rows.length,
    averageScore: avg(scores),
    averageAttendance: avg(attendance),
    averageStudyHours: avg(studyHours),
    highestScore: Math.max(...scores),
    lowestScore: Math.min(...scores),
    averagePreviousMarks: avg(rows.map((r) => r.previous_marks)),
    averageAssignmentScore: avg(rows.map((r) => r.assignment_score)),
    averageMidtermScore: avg(rows.map((r) => r.midterm_score)),
  }
}

export function scoreDistribution(rows) {
  const buckets = [
    { range: '0-49', min: 0, max: 49, count: 0 },
    { range: '50-59', min: 50, max: 59, count: 0 },
    { range: '60-69', min: 60, max: 69, count: 0 },
    { range: '70-79', min: 70, max: 79, count: 0 },
    { range: '80-100', min: 80, max: 100, count: 0 },
  ]
  rows.forEach((r) => {
    const bucket = buckets.find((b) => r.final_score >= b.min && r.final_score <= b.max)
    if (bucket) bucket.count += 1
  })
  return buckets
}
