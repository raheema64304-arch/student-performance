import React, { useState } from 'react'
import PredictionResult from '../components/PredictionResult'
import { VALID_RANGES, validateInput } from '../ml/preprocessing'
import { predictScore, categorize } from '../ml/training'

const DEFAULTS = {
  study_hours: 5,
  attendance: 80,
  previous_marks: 70,
  assignment_score: 75,
  midterm_score: 70,
  participation: 60,
  sleep_hours: 7,
  internet_access: 'Yes',
  extracurricular: 'No',
}

const SLIDER_FIELDS = [
  ['study_hours', 'Study Hours', 0.5],
  ['attendance', 'Attendance (%)', 1],
  ['previous_marks', 'Previous Marks', 1],
  ['assignment_score', 'Assignment Score', 1],
  ['midterm_score', 'Midterm Score', 1],
  ['participation', 'Participation', 1],
  ['sleep_hours', 'Sleep Hours', 0.5],
]

export default function PredictPerformance({ modelStatus, trainingResult }) {
  const [form, setForm] = useState(DEFAULTS)
  const [errors, setErrors] = useState({})
  const [result, setResult] = useState(null)

  const modelReady = modelStatus === 'ready' && trainingResult

  const handleSlider = (field, value) => {
    setForm((f) => ({ ...f, [field]: Number(value) }))
  }

  const handleSelect = (field, value) => {
    setForm((f) => ({ ...f, [field]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!modelReady) return

    const nextErrors = {}
    SLIDER_FIELDS.forEach(([field]) => {
      const err = validateInput(field, form[field])
      if (err) nextErrors[field] = err
    })
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) {
      setResult(null)
      return
    }

    try {
      const score = predictScore(trainingResult.model, trainingResult.stats, form)
      setResult({ score, category: categorize(score), input: { ...form } })
    } catch (err) {
      setResult(null)
      setErrors({ form: 'Something went wrong generating a prediction. Try adjusting the inputs.' })
    }
  }

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-black/5 p-6 space-y-5">
        {SLIDER_FIELDS.map(([field, label, step]) => {
          const [min, max] = VALID_RANGES[field]
          return (
            <div key={field}>
              <div className="flex justify-between text-sm mb-1">
                <label htmlFor={field} className="text-ink/70">{label}</label>
                <span className="text-ink font-medium">{form[field]}</span>
              </div>
              <input
                id={field}
                type="range"
                min={min}
                max={max}
                step={step}
                value={form[field]}
                onChange={(e) => handleSlider(field, e.target.value)}
                className="w-full accent-sage"
              />
              {errors[field] && <p className="text-xs text-red-600 mt-1">{errors[field]}</p>}
            </div>
          )
        })}

        <div className="grid grid-cols-2 gap-4 pt-1">
          <div>
            <label className="text-sm text-ink/70 block mb-1">Internet Access</label>
            <select
              value={form.internet_access}
              onChange={(e) => handleSelect('internet_access', e.target.value)}
              className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
            >
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>
          <div>
            <label className="text-sm text-ink/70 block mb-1">Extracurricular Activity</label>
            <select
              value={form.extracurricular}
              onChange={(e) => handleSelect('extracurricular', e.target.value)}
              className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
            >
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>
        </div>

        {errors.form && <p className="text-sm text-red-600">{errors.form}</p>}

        <button
          type="submit"
          disabled={!modelReady}
          className="w-full bg-ink text-white rounded-md py-2.5 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-ink/90 transition-colors"
        >
          {modelReady ? 'Predict Performance' : 'Preparing model…'}
        </button>
      </form>

      <div>
        {result ? (
          <PredictionResult score={result.score} category={result.category} input={result.input} />
        ) : (
          <div className="h-full min-h-[240px] bg-white rounded-lg border border-black/5 border-dashed flex items-center justify-center text-ink/40 text-sm p-6 text-center">
            Fill in the form and click Predict Performance to see a result here.
          </div>
        )}
      </div>
    </div>
  )
}
