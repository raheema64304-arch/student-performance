import React from 'react'
import {
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar,
} from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeSummary, scoreDistribution } from '../services/dataset'

export default function Dashboard({ rows }) {
  const summary = computeSummary(rows)
  const distribution = scoreDistribution(rows)

  const scatterData = (xKey) => rows.map((r) => ({ x: r[xKey], y: r.final_score }))

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard label="Total Students" value={summary.totalStudents} />
        <StatCard label="Average Score" value={summary.averageScore.toFixed(1)} />
        <StatCard label="Average Attendance" value={`${summary.averageAttendance.toFixed(1)}%`} />
        <StatCard label="Average Study Hours" value={`${summary.averageStudyHours.toFixed(1)} hrs`} />
        <StatCard label="Highest Score" value={summary.highestScore.toFixed(1)} />
        <StatCard label="Lowest Score" value={summary.lowestScore.toFixed(1)} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Study Hours vs Final Score" description="Each point is one student">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" />
              <XAxis type="number" dataKey="x" name="Study Hours" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="y" name="Final Score" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData('study_hours')} fill="#3F6659" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Attendance vs Final Score" description="Each point is one student">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" />
              <XAxis type="number" dataKey="x" name="Attendance" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="y" name="Final Score" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData('attendance')} fill="#C99A3A" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Previous Marks vs Final Score" description="Each point is one student">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" />
              <XAxis type="number" dataKey="x" name="Previous Marks" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="y" name="Final Score" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData('previous_marks')} fill="#1B2333" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Final Score Distribution" description="Number of students per score band">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distribution} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#3F6659" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
