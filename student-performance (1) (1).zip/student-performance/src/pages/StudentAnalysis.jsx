import React from 'react'
import {
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeSummary } from '../services/dataset'

export default function StudentAnalysis({ rows }) {
  const summary = computeSummary(rows)
  const scatterData = (xKey) => rows.map((r) => ({ x: r[xKey], y: r.final_score }))

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <StatCard label="Average Study Hours" value={summary.averageStudyHours.toFixed(1)} />
        <StatCard label="Average Attendance" value={`${summary.averageAttendance.toFixed(1)}%`} />
        <StatCard label="Average Previous Marks" value={summary.averagePreviousMarks.toFixed(1)} />
        <StatCard label="Average Assignment Score" value={summary.averageAssignmentScore.toFixed(1)} />
        <StatCard label="Average Midterm Score" value={summary.averageMidtermScore.toFixed(1)} />
        <StatCard label="Average Final Score" value={summary.averageScore.toFixed(1)} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Assignment Score vs Final Score">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" />
              <XAxis type="number" dataKey="x" name="Assignment Score" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="y" name="Final Score" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData('assignment_score')} fill="#3F6659" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Midterm Score vs Final Score">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" />
              <XAxis type="number" dataKey="x" name="Midterm Score" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="y" name="Final Score" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData('midterm_score')} fill="#C99A3A" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Sleep Hours vs Final Score">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" />
              <XAxis type="number" dataKey="x" name="Sleep Hours" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="y" name="Final Score" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData('sleep_hours')} fill="#1B2333" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Participation vs Final Score">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8e8e2" />
              <XAxis type="number" dataKey="x" name="Participation" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="y" name="Final Score" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={scatterData('participation')} fill="#B3462F" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
