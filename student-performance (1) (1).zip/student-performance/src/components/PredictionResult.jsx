import React from 'react'
import { buildPredictionReport, downloadTextFile } from '../utils/report'

export default function PredictionResult({ score, category, input }) {
  const handleDownload = () => {
    const report = buildPredictionReport({ score, category, input })
    downloadTextFile('prediction-report.txt', report)
  }

  const rows = [
    ['Study Hours', `${input.study_hours} hours`],
    ['Attendance', `${input.attendance}%`],
    ['Previous Marks', input.previous_marks],
    ['Assignment', input.assignment_score],
    ['Midterm', input.midterm_score],
  ]

  return (
    <div className="bg-white rounded-lg border border-black/5 p-6">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Predicted Score</p>
      <div className="flex items-end gap-2 mb-1">
        <span className="font-display text-5xl text-ink">{score.toFixed(1)}</span>
        <span className="text-ink/40 text-lg mb-1">/ 100</span>
      </div>
      <span
        className="inline-block px-3 py-1 rounded-full text-xs font-medium text-white mb-5"
        style={{ backgroundColor: category.color }}
      >
        {category.label} Performance
      </span>

      <div className="w-full h-2 bg-black/5 rounded-full overflow-hidden mb-6">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${score}%`, backgroundColor: category.color }}
        />
      </div>

      <div className="space-y-2 mb-5">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{value}</span>
          </div>
        ))}
      </div>

      <button
        onClick={handleDownload}
        className="w-full text-sm px-4 py-2 rounded-md border border-ink/15 text-ink hover:bg-black/5 transition-colors"
      >
        Download Report
      </button>
    </div>
  )
}
