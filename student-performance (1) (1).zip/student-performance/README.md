# Student Performance Analytics

Frontend-only ML app. React + Vite + Tailwind + TensorFlow.js + Recharts + PapaParse.
No backend, no external APIs. Everything (data load, training, prediction) runs in the browser.

## Run it

npm install
npm run dev

Open the printed local URL. First load: dataset loads, model trains (~50 epochs), then the dashboard is ready.

## Structure

- public/data/students.csv — sample dataset (300 rows, synthetic but statistically realistic)
- src/ml/ — preprocessing, model definition, training/evaluation
- src/services/dataset.js — CSV loading + summary stats
- src/pages/ — Dashboard, Predict Performance, Student Analysis, Model Performance
- src/components/ — Sidebar, Header, StatCard, ChartCard, PredictionResult

Swap in your own data by replacing public/data/students.csv, keeping the same column names.
